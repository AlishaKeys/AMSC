﻿using UnityEngine;
using System.Collections;

public class ForStrel : MonoBehaviour {

    private Strelba _strel;
    // Use this for initialization
    void Start()
    {
        _strel = GetComponentInParent<Strelba>();
    }


	void OnTriggerExit2D(Collider2D coll)
    {
        if (coll.tag == "Strel")
        {
			Destroy(coll.gameObject);
        }
    }
}
