﻿using UnityEngine;
using System.Collections;

public class Strelba : MonoBehaviour
{


    public GameObject strel;
    private Player _player;

    void Start()
    {
        _player = GetComponentInParent<Player>();
    }

    void FixedUpdate()
    {
		if (Input.GetKey(KeyCode.LeftControl))
        {  	
			if (Time.time % 0.5f == 0) 
			{
                GameObject newStrel = Instantiate(strel);
                newStrel.GetComponent<CircleCollider2D>().isTrigger = true;
                newStrel.name = "Blood";
                newStrel.transform.position = new Vector2(_player.transform.position.x + 0.1f, _player.transform.position.y);
				newStrel.GetComponent<Rigidbody2D> ().velocity = new Vector2 (12, 3.8f);
                newStrel.transform.position = new Vector2(_player.transform.position.x, _player.transform.position.y);
    		}
		}
	}
}

