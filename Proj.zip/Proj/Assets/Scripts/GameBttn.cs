﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class GameBttn : MonoBehaviour {

	void OnMouseDown () {

		SceneManager.LoadScene ("Menu");
	}
}
