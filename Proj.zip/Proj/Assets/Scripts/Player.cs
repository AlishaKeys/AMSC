﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour
{

    private float speedPers = 1;
    private int direction = 1;

    public Animator _animator;
    public Animator animator { get { return _animator; } }

    private Rigidbody2D rb;

    public bool jump;

	public GameObject[] hp;
	private float x = -3.58f;
	private GameObject [] array1; 
	private int k = 5;

	public GameObject BoomEff;


    void Start()
    {
        _animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();

    }

	void CreateEffects (GameObject _effect) {
		GameObject effect = Instantiate (_effect);
		if (effect.GetComponent<Renderer> () != null) {
			effect.GetComponent<Renderer> ().sortingLayerName = "Default";
			effect.GetComponent<Renderer> ().sortingOrder = 2;
		}
		effect.transform.position = transform.position;
		Destroy (effect, 0.3f);
	}

    void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.D))
        {
            Right();
        }

        if (Input.GetKey(KeyCode.A))
        {
            Left();
        }

        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.W))
        {
            Jump();
        }

		if (Input.GetKeyDown(KeyCode.G)) {
			CreateEffects(BoomEff);
		}
    }


   public void Right ()
    {
        _animator.SetBool("run", true);

        rb.velocity = new Vector2(direction * speedPers, rb.velocity.y);

    }

            
    public void Left()
    {
            _animator.SetBool("run", true);

            rb.velocity = new Vector2(-direction * speedPers, rb.velocity.y);
    }
 
   public void Jump ()
    {
            if (jump)
            {
                _animator.SetBool("run", false);
                rb.velocity = new Vector2(rb.velocity.x, 3);
            }
    }
	private bool _hitTrigger = true;
	void OnTriggerEnter2D(Collider2D target)
	{

		if (target.name == "Blood") {
			if (_hitTrigger) {
				k -= 1;
				Debug.Log (k);
				if (k >= 0) {
					Destroy (hp [k].gameObject);
				}
				_hitTrigger = false;
			}
			LeanTween.color (gameObject, Color.red, 0.5f).onComplete = (() => LeanTween.color (gameObject, Color.white, 0.5f).setOnComplete(delegate() {
				_hitTrigger = true;

			}));

			//Destroy(this.gameObject);
		}

	}
}