﻿using UnityEngine;
using System.Collections;

public class SpawnCntlr : MonoBehaviour {

	public GameObject enemy;
	public GameObject Bullet;
	private GameObject newEnemy;
	// Use this for initialization
	void Start () {
	
	}
	
	void OnTriggerEnter2D (Collider2D collider) {
		if (collider.tag == "Player") {

			newEnemy = Instantiate (enemy);
			newEnemy.transform.position = new Vector2(11.76412f, transform.position.y);
			newEnemy.AddComponent<Rigidbody2D> ().isKinematic = true;
			newEnemy.AddComponent<CircleCollider2D>();
			InvokeRepeating ("ShootDamn", 1f, 1f);

		}




}

	void ShootDamn() 
	{
		GameObject newStrel = Instantiate(Bullet);
		newStrel.GetComponent<SpriteRenderer> ().flipX = true;
		newStrel.GetComponent<CircleCollider2D>().isTrigger = true;
		newStrel.name = "Blood";
		newStrel.transform.position = new Vector2(newEnemy.transform.position.x - 0.1f, newEnemy.transform.position.y);
		newStrel.GetComponent<Rigidbody2D> ().velocity = new Vector2 (-8, 2f);
		Destroy (newStrel, 1);

	}

	void OnCollisionEnter2D (Collision2D col) {
		//if (col.tag == "Player") {
			

}
}
