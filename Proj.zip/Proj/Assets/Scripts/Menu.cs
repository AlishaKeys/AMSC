﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour {


	void OnMouseDown () {
		
		SceneManager.LoadScene ("MainScene");
}
}
